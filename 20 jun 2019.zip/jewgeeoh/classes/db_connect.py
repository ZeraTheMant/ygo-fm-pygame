import sqlite3

conn = sqlite3.connect("../database/main.db")
c = conn.cursor()
