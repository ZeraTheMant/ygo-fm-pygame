from player_init import Guardian_Stars_Container

class Card(object):
    card_type = None
    
    def __init__(self, name, img, attr_img, text, duelist):
        self.name = name
        self.img = img
        self.attr_img = attr_img
        self.text = text
        self.card_owner = duelist
        self.current_user = None
        self.is_set = False
        self.current_zone = None

    def getAttr(self, v):
        for attr, val in self.__dict__.items():
            if attr == attr_name:
                return val

    def getUser(self):
        return self.current_user

    def setUser(self, current_user):
        self.current_user = current_user

    def removeFromPlace(self, mode):
        if mode == "To hand":
            self.returnToHand(self.card_owner)
        elif mode == "To graveyard":
            self.sendToGrave(self.card_owner)
        else:
            self.banish(self.card_owner)

    def returnToHand(self, owner):
        owner.addToHand(self)
        self.current_zone = None

    def sendToGrave(self, owner):
        owner.duelist_zone.graveyard.placeCardToZone(self)
        self.current_zone = None

    def banish(self, owner):
        owner.duelist_zone.graveyard.banished_zone(self)
        self.current_zone = None
        
    def setZone(self, zone):
        self.current_zone = zone
        
    def activate(self):
        return None

    def selectGuardianStar(self):
        return None
        
    def set(self):
        self.is_set = True
        self.selectGuardianStar()
        

class MonsterCard(Card):
    card_type = "Monster"
    
    def __init__(self, name, img, attr_img, text, duelist, monster_type, monster_attr, atk_points, def_points, star_1, star_2, level):
        super().__init__(name, img, attr_img, text, duelist)
        self.monster_type = monster_type
        self.monster_attr = monster_attr
        self.atk_points = atk_points
        self.def_points = def_points
        self.current_atk_points = self.atk_points
        self.current_def_points = self.def_points
        self.guardian_star_list = [Guardian_Stars_Container.returnGuardianStarById(star_1), Guardian_Stars_Container.returnGuardianStarById(star_2)]
        self.guardian_star = None
        self.in_atk_position = True
        self.has_attacked = False
        self.level = level

    def changePosition(self):
        self.in_atk_position = not self.in_atk_position
        
    def normal_summon(self):
        self.selectGuardianStar()

    def selectGuardianStar(self):
        ctr = 0
        for gs in self.guardian_star_list:
            strong_against = Guardian_Stars_Container.returnGuardianStarById(gs.getStrongerAgainstId()).getName()
            weak_against = Guardian_Stars_Container.returnGuardianStarById(gs.getWeakerAgainstId()).getName()
            print("Index: " + str(ctr) + ". Name: [" + gs.getName() + "] Strong against: [" + strong_against + "] Weak against: [" + weak_against + "]")
            ctr += 1
            
        choice = int(input("Enter the index of your preferred guardian star: "))
        self.guardian_star = self.guardian_star_list[choice]
        
    def flip(self):
        self.is_set = False
        
    def battle(self, attacking_card, attacked_card):
        damage_taken = 0
        if attacked_card.in_atk_position:
            if attacking_card.current_atk_points == attacked_card.current_atk_points:
                winning_card = None
            elif attacking_card.current_atk_points > attacked_card.current_atk_points:
                winning_card = attacking_card
                damage_taken = attacked_card.current_atk_points - attacking_card.current_atk_points
            else:
                winning_card = attacked_card
                damage_taken = attacking_card.current_atk_points - attacked_card.current_atk_points
        else:
            if attacking_card.current_atk_points == attacked_card.current_def_points:
                winning_card = None
            elif attacking_card.current_atk_points > attacked_card.current_def_points:
                winning_card = attacking_card
            else:
                winning_card = attacked_card
                damage_taken = attacking_card.current_atk_points - attacked_card.current_def_points
             
        if winning_card:
            winning_card.card_owner.opponent.changeLifePointsAmount(damage_taken)
        return winning_card
        
    def attack(self, attacked_card):
        if self.is_set:
            self.flip()
        if not attacked_card:
            self.card_owner.opponent.changeLifePointsAmount(-self.current_atk_points)
        else:
            attacked_card.flip()
            winning_card = self.battle(self, attacked_card)
            if winning_card == None and attacked_card.in_atk_position:
                self.zone.removeCardFromZone(self, "To graveyard")
                attacked_card.zone.removeCardFromZone(self, "To graveyard")
            elif winning_card == attacked_card and attacked_card.in_atk_position:
                self.zone.removeCardFromZone(self, "To graveyard")
            elif winning_card == self:
                attacked_card.zone.removeCardFromZone(attacked_card, "To graveyard")
        self.has_attacked = True

class SpellOrTrapCard(Card):
    def __init__(self, name, img, attr_img, text, duelist, spell_or_trap_type, spell_or_trap_type_img):
        super().__init__(name, img, attr_img, text, duelist)
        self.spell_or_trap_type = spell_or_trap_type
        self.spell_type_img = spell_or_trap_type_img
        
    def activate(self):
        self.is_set = False
        if self.spell_or_trap_type != "Normal":
            self.card_owner.duelist_zone.getAttr("graveyard").removeCardFromZone(self, "To graveyard")

class SpellCard(SpellOrTrapCard):
    card_type = "Spell"

class FieldSpellCard(SpellCard):
    x = 'x'

class TrapCard(SpellOrTrapCard):
    card_type = "Trap"
