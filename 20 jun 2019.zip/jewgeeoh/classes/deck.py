import random
from db_connect import conn, c
from card import *

class Deck(object):
    CARD_LIMIT = 40

    def __init__(self, deck_id, duelist, is_human):
        self.cards = []
        self.deck_id = deck_id
        self.build(duelist, is_human)

    def build(self, duelist, is_human):
        if is_human:
            c.execute("""
                SELECT
                    Cards.*,
                    Deck_Cards.Quantity
                FROM
                    Cards
                INNER JOIN
                    Deck_Cards
                ON
                    Cards.Card_ID = Deck_Cards.Card_ID
                WHERE Deck_Cards.Deck_ID = (?)""", (self.deck_id,))
        else:
            c.execute("""
                SELECT
                    Cards.*,
                    Opponent_Deck_Cards.Quantity
                FROM
                    Cards
                INNER JOIN
                    Opponent_Deck_Cards
                ON
                    Cards.Card_ID = Opponent_Deck_Cards.Card_ID
                WHERE Opponent_Deck_Cards.Deck_ID = (?)""", (self.deck_id,))
        
        for row in c.fetchall():
            for _ in range(row[15]):
                if row[2] == "Monster":
                    new_card = MonsterCard(row[1], row[4], row[3], row[5], duelist, row[6], row[7], row[8], row[9], row[13], row[14], row[10])
                elif row[2] == "Spell":
                    if row[11] == "Field":
                        new_card = FieldSpellCard(row[1],
                                                  row[4],                             
                                                  row[3],
                                                  row[5],
                                                  duelist,
                                                  row[11],
                                                  row[12]
                                                  )
                self.cards.append(new_card)
                    
        #c.close()
        #conn.close()

    def getCards(self):
        return self.cards

    def shuffle(self):
        random.shuffle(self.cards)

    def draw(self):
        try:
            card = self.cards.pop()
        except IndexError:
            return "You have no cards left to play."
        return card

"""
x = Deck(1)
for i in range(len(x.cards)):
    print(x.cards[i].name)

"""
